import { Database } from 'lucide-react'

export default function Backups() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-3xl font-bold text-white">Backups</h1><p className="text-dark-400">Gerencie seus backups</p></div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6"><div className="text-2xl font-bold text-white mb-1">0</div><p className="text-dark-400 text-sm">Backups</p></div>
        <div className="card p-6"><div className="text-2xl font-bold text-white mb-1">Diário</div><p className="text-dark-400 text-sm">Automático</p></div>
        <div className="card p-6"><div className="text-2xl font-bold text-white mb-1">01:00</div><p className="text-dark-400 text-sm">Próximo</p></div>
      </div>

      <div className="card p-6"><h2 className="text-lg font-semibold text-white mb-4">Backups</h2><p className="text-dark-400">Nenhum backup disponível</p></div>
    </div>
  )
}
