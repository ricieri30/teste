import { Settings as SettingsIcon, Save } from 'lucide-react'
import toast from 'react-hot-toast'

export default function Settings() {
  const handleSave = () => toast.success('Configurações salvas!')

  return (
    <div className="space-y-6">
      <div><h1 className="text-3xl font-bold text-white">Configurações</h1><p className="text-dark-400">Gerencie suas preferências</p></div>

      <div className="card p-6">
        <h2 className="text-lg font-semibold text-white mb-4">Webhooks</h2>
        <div className="space-y-4">
          <div><label className="block text-sm font-medium text-white mb-2">URL</label><input type="text" className="input" placeholder="https://hooks.slack.com/..." /></div>
        </div>
      </div>

      <button onClick={handleSave} className="btn-primary"><Save className="w-4 h-4 mr-2" />Salvar</button>
    </div>
  )
}
